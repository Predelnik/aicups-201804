#include "../nlohmann/json.hpp"
#include "Strategy.h"

using namespace std;

int main() {
	Strategy strategy;
	strategy.run();
	return 0;
}